package com.edutech.classroom.repository;

import com.edutech.classroom.entity.CourseCategory;
import org.springframework.data.repository.CrudRepository;

public interface CourseRepository extends CrudRepository<CourseCategory, Integer> {
}
