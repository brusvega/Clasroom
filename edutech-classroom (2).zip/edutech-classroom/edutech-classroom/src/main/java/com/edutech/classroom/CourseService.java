package com.edutech.classroom;

import com.edutech.classroom.dto.CourseDTO;
import com.edutech.classroom.entity.Course;
import com.edutech.classroom.exception.ResourceNotFoundException;
import com.edutech.classroom.repository.CourseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseRepository repo;

    public List<CourseDTO> findAll() {
        return repo.findAll().stream()
                .map(CourseDTO::fromEntity)
                .toList();
    }

    public CourseDTO findById(Integer id) {
        Course entity = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Curso no encontrado"));
        return CourseDTO.fromEntity(entity);
    }

    public CourseDTO create(CourseDTO dto) {
        Course entity = dto.toEntity();
        Course saved = repo.save(entity);
        return CourseDTO.fromEntity(saved);
    }

    public CourseDTO update(Integer id, CourseDTO dto) {
        Course existing = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Curso no encontrado"));
        Course updated = dto.toEntity();
        updated.setId(existing.getId());
        return CourseDTO.fromEntity(repo.save(updated));
    }

    public void delete(Integer id) {
        Course entity = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Curso no encontrado"));
        repo.delete(entity);
    }
}
