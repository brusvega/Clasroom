package com.edutech.classroom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdutechClassroomApplicationTests {

	@Test
	void contextLoads() {
	}

}
